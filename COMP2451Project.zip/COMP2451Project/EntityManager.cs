﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using COMP2451Project;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
/// <summary>
/// AUTHOR: Flynn Osborne
/// DATE: 19/01/2022
/// </summary>
namespace COMP3451Project.Managers
{
    class EntityManager
    {
        // Variable to hold game entity
        public IEntity entity;

        // List to hold the entities
        public List<IEntity> entities;

        // Variables to hold factories for the ball and paddles
        public IFactory<Paddle> _paddleFactory;
        public IFactory<Ball> _ballFactory;

        public EntityManager(IFactory<Paddle> pPaddleFactory, IFactory<Ball> pBallFactory) 
        {
            // Create a new entity list
            entities = new List<IEntity>();

            // Initialise the ball and paddle factories
            _paddleFactory = pPaddleFactory;
            _ballFactory = pBallFactory;
        }

        public IEntity CreateEntity(int which , Vector2 pLocation , Texture2D pTexture)
        {
            // pOrderNumber dictates which entity will be instantiated

            // 1 = Paddle (Player 1)
            // 2 = Paddle (Player 2)
            // other = Ball
            
            // Return the chosen entity
            IEntity entity;
            if (which == 1)
            {
                //entity = new Paddle(pLocation, PlayerIndex.One);

                entity = _paddleFactory.Create<Paddle>();

                ((PongEntity)entity).Content(pTexture);
            }
            else if (which  == 2) 
            {
                entity = new Paddle(pLocation, PlayerIndex.Two);
                ((PongEntity)entity).Content(pTexture);
            }

            else 
            {
                //entity = new Ball(pLocation);

                entity = _ballFactory.Create<Ball>();
                ((PongEntity)entity).Content(pTexture);
            }

            entities.Add(entity);
            return entity;
        }

        public List<IEntity> CreateEntityList(Vector2[] pVector2)
        {
            // Reset the entity list



            // pOrderNumber dictates which list of entities will be instantiated

            // 0 = Patients
            // 1 = Top Walls
            // 2 = Top Walls (with doorway)
            // 3 = Bottom Walls
            // 4 = Bottom Walls (with doorway)
            // 5 = Left Walls
            // 6 = Left Walls (with doorway)
            // 7 = Right Walls
            // 8 = Right Walls (with doorway)
            /*
            if (pOrderNumber == 0)
            {
                // Instantiate the patients
                for (int i = 0; i < 3; i++)
                {
                    entity = new Patient(800, 300, pScreenHeight, pScreenWidth, pSpriteBatch);
                    entities.Add(entity);
                }
            }
            else if (pOrderNumber == 1)
            {
                // Instantiate the top walls
                for (int i = 0; i < 11; i++)
                {
                    entity = new WallHorizontal(150 * i, -150, pScreenHeight, pScreenWidth, pSpriteBatch);
                    entities.Add(entity);
                }
            }
            else if (pOrderNumber == 2)
            {
                // Instantiate the top walls (with doorway)
                for (int i = 0; i < 4; i++)
                {
                    entity = new WallHorizontal(150 * i, -200, pScreenHeight, pScreenWidth, pSpriteBatch);
                    entities.Add(entity);
                    entity = new WallHorizontal(pScreenWidth - (150 * i), -200, pScreenHeight, pScreenWidth, pSpriteBatch);
                    entities.Add(entity);
                }
            }
            else if (pOrderNumber == 3)
            {
                // Instantiate the bottom walls
                for (int i = 0; i < 11; i++)
                {
                    entity = new WallHorizontal(150 * i, pScreenHeight + 500, pScreenHeight, pScreenWidth, pSpriteBatch);
                    entities.Add(entity);
                }
            }
            else if (pOrderNumber == 4)
            {
                // Instantiate the bottom walls (with doorway)
                for (int i = 0; i < 4; i++)
                {
                    entity = new WallHorizontal(150 * i, pScreenHeight + 500, pScreenHeight, pScreenWidth, pSpriteBatch);
                    entities.Add(entity);
                    entity = new WallHorizontal(pScreenWidth - (150 * i), pScreenHeight + 500, pScreenHeight, pScreenWidth, pSpriteBatch);
                    entities.Add(entity);
                }
            }
            else if (pOrderNumber == 5)
            {
                // Instantiate the left walls
                for (int i = 0; i < 6; i++)
                {
                    entity = new WallVertical(-100, 150 * i, pScreenHeight, pScreenWidth, pSpriteBatch);
                    entities.Add(entity);
                }
            }
            else if (pOrderNumber == 6)
            {
                // Instantiate the left walls (with doorway)
                for (int i = 0; i < 2; i++)
                {
                    entity = new WallVertical(-100, 150 * i, pScreenHeight, pScreenWidth, pSpriteBatch);
                    entities.Add(entity);
                    entity = new WallVertical(-100, pScreenHeight - (150 * i), pScreenHeight, pScreenWidth, pSpriteBatch);
                    entities.Add(entity);
                }
            }
            else if (pOrderNumber == 7)
            {
                // Instantiate the right walls
                for (int i = 0; i < 6; i++)
                {
                    entity = new WallVertical(pScreenWidth + 500, 150 * i, pScreenHeight, pScreenWidth, pSpriteBatch);
                    entities.Add(entity);
                }
            }
            else if (pOrderNumber == 8)
            {
                // Instantiate the right walls (with doorway)
                for (int i = 0; i < 2; i++)
                {
                    entity = new WallVertical(pScreenWidth + 500, 150 * i, pScreenHeight, pScreenWidth, pSpriteBatch);
                    entities.Add(entity);
                    entity = new WallVertical(pScreenWidth + 500, pScreenHeight - (150 * i), pScreenHeight, pScreenWidth, pSpriteBatch);
                    entities.Add(entity);
                }
            }
            */
            // Return the entity list
            return entities;
        }
    }
}
